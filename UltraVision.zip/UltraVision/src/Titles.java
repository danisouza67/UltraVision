public class Titles {

    String title;
    String title_id;


    public Titles(String title, String title_id){
        this.title = title;
        this.title_id = title_id;
    }



}
